# musicPyLib 


to download the library you need to issue the following command >
````
pip install git+https://@github.com/Mordween/musicPyLib.git
````
If you have problem with python cache, use : 
````
pip cache purge
````
### How to use this lib? :

You just have to use classic import / from import. <br>
The syntaxe is just longer. For exemple, in order to use SFTP, you can write : <br>
````
from musicPyLib.musicPyLib import music

#launches the program
music()
````